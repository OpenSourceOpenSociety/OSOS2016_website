<div class="misc-pub-section misc-pub-visibility" id="visibility">
  Time Remaining: <span>1d5h39m25s</span>
</div>
