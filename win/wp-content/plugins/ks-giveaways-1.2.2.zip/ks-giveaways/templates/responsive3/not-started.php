<div class="row text-center">
  <div class="small-12 columns">
    <h3 class="timer">
      <div id="countdown" data-until="<?php echo ks_giveaways_get_date_start() ?>"></div>
    </h3>
  </div>
</div>
<div class="row text-center">
  <div class="small-12 columns">
    <h4>Slow down! Giveaway hasn't started yet. Come back later.</h4>
  </div>
</div>
