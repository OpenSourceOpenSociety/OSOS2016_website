If you want to modify or clone this theme please copy it to the custom
theme directory first otherwise any modifications will likely be lost
when the plugin is upgraded.

Custom Theme Location
=====================
%wp_content_dir%/ks-giveaways-themes